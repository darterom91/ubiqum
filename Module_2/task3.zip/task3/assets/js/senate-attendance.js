var datas = JSON.stringify(data);
var dataForm = JSON.parse(datas);
var members =  dataForm.results[0].members;
var filterMissedAsc = [], filterMissedDesc = [];
var contR = 0, contD = 0, contI = 0, contTotal = 0;
var cont = 0;
var rPCT = 0, dPCT = 0, iPCT = 0, tPCT = 0;
var tablaParty = '', tablaAsc = '', tablaDesc = '';
var totalVotesR = 0;
var totalVotesD = 0;
var totalVotesI = 0;
var totalVotesTOT = 0;

function totalPCTVotesAsc() {
  cont=0;
  console.log(members.length);
  console.log("for 1");
  // for (var i in members) {
  //   console.log(members[i].last_name + " % votes: " + members[i].votes_with_party_pct);
  // }

  members.sort(function (a, b) {
    console.log(a.missed_votes + " y " + b.missed_votes);
    return (a.missed_votes - b.missed_votes);
  });

  console.log("for 2");
  for (var i in members) {
    if (members[i].missed_votes_pct > 10) {
      if(cont<5){
        filterMissedAsc[i] = members[i];
        console.log("filterMissedAsc: " + members[i].last_name + " % votes: " + filterMissedAsc[i].missed_votes);
      }
      cont++;
    }
  }
  senateTableMissedAsc();
}

function totalPCTVotesDesc() {
  cont = 0;
  console.log("totalPCTVotesDesc");
  members.reverse();
  for (var i in members) {
    if (members[i].missed_votes_pct < 10) {
      if (cont < 5) {
      filterMissedDesc[i] = members[i];
      console.log("filterMissedDesc: " + members[i].last_name + " % votes: " + filterMissedDesc[i].missed_votes);
      }
      cont++;
    }
  }
  senateTableMissedDesc();
}

function senateTableMissedAsc() {

  tablaAsc = '';
  // Cabecera de la tabla th

  tablaAsc +=
    '<thead><tr>' +
    '<th>Name</th>' +
    '<th>Number of Missed Votes</th>' +
    '<th>% Missed</th>' +
    '</tr></thead>';

  //cuerpo de  la tabla td num.toFixed(2)
  for (var i in filterMissedAsc) {
    tablaAsc +=
      '<tbody><tr>' +
      '<td>' + filterMissedAsc[i].first_name + '</td>' +
      '<td>' + filterMissedAsc[i].missed_votes + '</td>' +
      '<td>' + filterMissedAsc[i].missed_votes_pct + '</td>' +
      '</tr></tbody>'
  }

  document.getElementById('senate-attendance-asc').innerHTML = tablaAsc;
}

function senateTableMissedDesc() {

  tablaDesc = '';
  // Cabecera de la tabla th

  tablaDesc +=
    '<thead><tr>' +
    '<th>Name</th>' +
    '<th>Number of Missed Votes</th>' +
    '<th>% Missed</th>' +
    '</tr></thead>';

  //cuerpo de  la tabla td num.toFixed(2)
  for (var i in filterMissedDesc) {
    tablaDesc +=
    '<tbody><tr>' +
    '<td>' + filterMissedDesc[i].first_name+'</td>' +
    '<td>' + filterMissedDesc[i].missed_votes +'</td>' +
    '<td>' + filterMissedDesc[i].missed_votes_pct+'</td>'+
    '</tr></tbody>'
  }

  document.getElementById('senate-attendance-desc').innerHTML = tablaDesc;
}

function calculatePCTVotes() {
  for (var i in dataForm.results[0].members) {
    if(dataForm.results[0].members[i].party=="R"){
      console.log("member: " + dataForm.results[0].members[i].last_name + " votos: " + (dataForm.results[0].members[i].total_votes - dataForm.results[0].members[i].missed_votes) + " votes_with_party_pct: " + dataForm.results[0].members[i].votes_with_party_pct + " Party: " + dataForm.results[0].members[i].party);

      totalVotesR = totalVotesR + (dataForm.results[0].members[i].total_votes - dataForm.results[0].members[i].missed_votes);

    }

    if (dataForm.results[0].members[i].party == "D") {
      console.log("member: " + dataForm.results[0].members[i].last_name + " votos: " + (dataForm.results[0].members[i].total_votes - dataForm.results[0].members[i].missed_votes) + " votes_with_party_pct: " + dataForm.results[0].members[i].votes_with_party_pct + " Party: " + dataForm.results[0].members[i].party);

      totalVotesD = totalVotesD + (dataForm.results[0].members[i].total_votes - dataForm.results[0].members[i].missed_votes);

    }

    if (dataForm.results[0].members[i].party == "I") {
      console.log("member: " + dataForm.results[0].members[i].last_name + " votos: " + (dataForm.results[0].members[i].total_votes - dataForm.results[0].members[i].missed_votes) + " votes_with_party_pct: " + dataForm.results[0].members[i].votes_with_party_pct + " Party: " + dataForm.results[0].members[i].party);

      totalVotesI = totalVotesI + (dataForm.results[0].members[i].total_votes - dataForm.results[0].members[i].missed_votes);

    }
  }
  console.log("votos totales Republicans: "+totalVotesR);
  console.log("votos totales Democrats: " + totalVotesD);
  console.log("votos totales Independents: " + totalVotesI);
  
  totalVotesTOT = totalVotesR + totalVotesD;
  totalVotesTOT = totalVotesTOT + totalVotesI;

  console.log("votos totales del Total: " + totalVotesTOT);
  rPCT = (totalVotesR / totalVotesTOT) * 100;
  dPCT = (totalVotesD / totalVotesTOT) * 100;
  iPCT = (totalVotesI / totalVotesTOT) * 100;
  
  tPCT = rPCT + dPCT + iPCT;

  console.log("Republicans votes: " + rPCT);
  console.log("Democrats votes: " + dPCT);
  console.log("Independents votes: " + iPCT);
  
  partyTablePCT();
}

function numberPartyMembers() {
  for (var i in dataForm.results[0].members) {
    if (dataForm.results[0].members[i].party == 'R') {
      console.log(
        'Member: ' +
          dataForm.results[0].members[i].last_name +
          ' is of the party ' +
          dataForm.results[0].members[i].party
      );
      contR++;
    }
  }

  for (var i in dataForm.results[0].members) {
    if (dataForm.results[0].members[i].party == 'D') {
      console.log(
        'Member: ' +
          dataForm.results[0].members[i].last_name +
          ' is of the party ' +
          dataForm.results[0].members[i].party
      );
      contD++;
    }
  }

  for (var i in dataForm.results[0].members) {
    if (dataForm.results[0].members[i].party == 'I') {
      console.log(
        'Member: ' +
          dataForm.results[0].members[i].last_name +
          ' is of the party ' +
          dataForm.results[0].members[i].party
      );
      contI++;
    }
  }

  console.log('Quantity of Republicans: '+contR);
  console.log('Quantity of Democrats: '+contD);
  console.log('Quantity of Independent: '+contI);

  contTotal = contR + contD;
  contTotal =  contTotal + contI;

  console.log('Quantity of Total: ' + contTotal);
  // rPCT = contR / contTotal;
  // dPCT = contD / contTotal;
  // iPCT = contI / contTotal;

  // rPCT = rPCT * 100;
  // dPCT = dPCT * 100;
  // iPCT = iPCT * 100
  partyTablePCT();
}

function partyTablePCT() {

  tabla = '';
  // Cabecera de la tabla th

  tabla +=
    '<thead><tr>' +
    '<th>Party</th>' +
    '<th>Number of Reps</th>' +
    '<th>% Voted with Party</th>' +
    '</tr></thead>';

  //cuerpo de  la tabla td num.toFixed(2)
  tabla += 
    '<tbody><tr>'+
    '<td>Democrats</td>'+
    '<td>'+contD+'</td>'+
    '<td>'+dPCT.toFixed(2)+'</td></tr>'+
    '<tr><td>Republicans</td>'+
    '<td>'+contR+'</td>'+
    '<td>'+rPCT.toFixed(2)+'</td></tr>'+
    '<tr><td>Independents</td>'+
    '<td>'+contI+'</td>'+
    '<td>'+iPCT.toFixed(2)+'</td>'+
    '<tr><td>Total</td>'+
    '<td>'+contTotal+'</td>'+
    '<td>'+tPCT.toFixed(0)+'</td>'+
    '</tr></tbody>'

  document.getElementById('senate-attendance').innerHTML = tabla;
}